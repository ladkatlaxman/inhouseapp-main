﻿function logEvent(event) {
    
    event = event || window.event;
    document.getElementById("mainBody").style.marginLeft = "220px";
    
}


function clearEvent(event) {

     event = event || window.event;
    document.getElementById("mainBody").style.marginLeft = "60px ";

    
}
